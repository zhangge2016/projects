package com.flink.udf;

public class Test {

  public static void main(String[] args) {
    System.out.println(System.currentTimeMillis() / 1000);

  }
}
