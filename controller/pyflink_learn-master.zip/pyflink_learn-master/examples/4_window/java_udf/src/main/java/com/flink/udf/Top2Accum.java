package com.flink.udf;

/**
 * Accumulator for Top2.
 */
public class Top2Accum {
  public Integer first;
  public Integer second;
}


